/**
 * $Revision: 161 $
**/


#if !defined(GUARD_KIMTEXT_H)
#define GUARD_KIMTEXT_H

namespace kim {

	/**/
	class text
	{};

}

#endif	/* GUARD_KIMTEXT_H */


